/*********************************************************************************************************//**
 * @file    CAN_Legacy/TxRxLoopback/main.c
 * @version $Rev:: 8260         $
 * @date    $Date:: 2024-11-05 #$
 * @brief   Main program.
 *************************************************************************************************************
 * @attention
 *
 * Firmware Disclaimer Information
 *
 * 1. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, which is supplied by Holtek Semiconductor Inc., (hereinafter referred to as "HOLTEK") is the
 *    proprietary and confidential intellectual property of HOLTEK, and is protected by copyright law and
 *    other intellectual property laws.
 *
 * 2. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, is confidential information belonging to HOLTEK, and must not be disclosed to any third parties
 *    other than HOLTEK and the customer.
 *
 * 3. The program technical documentation, including the code, is provided "as is" and for customer reference
 *    only. After delivery by HOLTEK, the customer shall use the program technical documentation, including
 *    the code, at their own risk. HOLTEK disclaims any expressed, implied or statutory warranties, including
 *    the warranties of merchantability, satisfactory quality and fitness for a particular purpose.
 *
 * <h2><center>Copyright (C) Holtek Semiconductor Inc. All rights reserved</center></h2>
 ************************************************************************************************************/

/* Includes ------------------------------------------------------------------------------------------------*/
#include "ht32.h"
#include "ht32_board.h"
#include "ht32_board_config.h"
#include "can_api.h"
#include "string.h"

/** @addtogroup HT32_Series_Peripheral_Examples HT32 Peripheral Examples
  * @{
  */

/** @addtogroup CAN_Legacy_Examples CAN_Legacy
  * @{
  */

/** @addtogroup TxRxLoopback
  * @{
  */


/* Global variables ----------------------------------------------------------------------------------------*/
u32 gCanTimeout;

/* Private function prototypes -----------------------------------------------------------------------------*/
void CKCU_Configuration(void);
void GPIO_Configuration(void);
void SysTick_Configuration(void);

/* Global functions ----------------------------------------------------------------------------------------*/
/*********************************************************************************************************//**
  * @brief  Main program.
  * @retval None
  ***********************************************************************************************************/
int main(void)
{
  CKCU_Configuration();               /* System Related configuration                                       */
  GPIO_Configuration();               /* GPIO Related configuration                                         */
  HT32F_DVB_LEDInit(HT_LED1);         /* LED1 configuration                                                 */
  RETARGET_Configuration();           /* Retarget Related configuration                                     */
  printf("\r\nCAN TxRxLoopback. System Core Clock %u \r\n", (u32)SystemCoreClock);

  SysTick_Configuration();            /* Timebase 1ms                                                       */

  CAN_Configuration();                /* CAN Related configuration                                          */

  HT32F_DVB_LEDOff(HT_LED1);

  SendFirstTestDataD904();            /* Send Test Data 0xD9 0x04                                           */

  while(1)
  {
    s32 ret = GetCanStatus(HT_CAN0);  /* Get CAN Status */

    if(ret == CAN_RET_BUSOFF_RCY)
    {
      /* CANbus at Bus-Off state */
      HT_CAN0->CR &= ~CAN_CR_INIT_Msk;

      /* Bus-Off recovery sequence.128 * 11 consecutive recessive bits.                     `                */
      /* This example waits for the longest time, BitRate = 5K ==> (1/5K) * 128/11 = 0.282s .                */
      gCanTimeout=282; /* Delay 282ms */
      while(gCanTimeout){}
    }
    else if(ret == CAN_RET_RXOK)
    {
      /* Received Data */
      ReadAllNewDataMsgObj(HT_CAN0, &recvQ);

      while(RmemDelta(recvQ.rptr, recvQ.sptr, FIFO_DEPTH))
      {
        /*  Rx FIFO is no empty*/
        STR_CANMSG_T_TypeDef rrMsg={0x00};

        /* Pop Rx FIFO(recvQ) Buffer to Rx Msg(rrMsg) */
        memcpy(&rrMsg, &recvQ.msg[recvQ.sptr++], sizeof(rrMsg));
        if(recvQ.sptr == FIFO_DEPTH)
        {
          recvQ.sptr = 0;
        }

        if(rrMsg.Id == CAN_RECV_ID)
        {
          
          /* Push Rx Msg(rrMsg) to Tx FIFO Buffer(sendQ) */
          memcpy(&sendQ.msg[sendQ.rptr++], &rrMsg, sizeof(rrMsg));
          if(sendQ.rptr == FIFO_DEPTH)
          {
            sendQ.rptr = 0;
          }
        }
      }
    }
    else if(ret == CAN_RET_IDLE) /* BUS idle */
    {
      if(RmemDelta(sendQ.rptr, sendQ.sptr, FIFO_DEPTH))
      {
        STR_CANMSG_T_TypeDef tMsg={0x00};
        CAN_MSG_TypeDef _TxMsg;
        /* the messages will be transferred because "Send FIFO" is not empty. */
        u32 i;
        
        /* Pop Tx FIFO(sendQ) Buffer to Tx Msg(tMsg) */
        memcpy(&tMsg,&sendQ.msg[sendQ.sptr++],  sizeof(tMsg));

        if(sendQ.sptr == FIFO_DEPTH)
        {
          sendQ.sptr = 0;
        }

        _TxMsg.MsgNum = 17;
        _TxMsg.Id        = CAN_SEND_ID;
        _TxMsg.FrameType = tMsg.FrameType;
        _TxMsg.IdType    = tMsg.IdType;
        CAN_Transmit(HT_CAN0, &_TxMsg, tMsg.Data, tMsg.DLC);

        printf("\r\nTx(<==), ID %06d, DLC %02d, EXT %d, Data: ", tMsg.Id, tMsg.DLC, tMsg.IdType);
        for(i = 0; i<tMsg.DLC; i++)
        {
          printf("%02X ", tMsg.Data[i]);
        }

        /* Send message. */
        HT32F_DVB_LEDOn(HT_LED1);
        while(!(HT_CAN0->SR & CAN_SR_TXOK_Msk));
        printf("Finish\r\n");
        /* Clear TXOK flag. */
        HT_CAN0->SR &= ~CAN_SR_TXOK_Msk;
        /* Send message OK */
        HT32F_DVB_LEDOff(HT_LED1);
      }
    }
  }
}
/*********************************************************************************************************//**
  * @brief  BFTM Configuration.
  * @retval None
  ***********************************************************************************************************/
void SysTick_Configuration(void)
{
  SYSTICK_ClockSourceConfig(SYSTICK_SRC_STCLK);       /* Default : CK_AHB/8                                 */
  SYSTICK_SetReloadValue(SystemCoreClock / 8 / 1000); /* (CK_AHB/8/1000) = 1ms on chip                      */
  SYSTICK_IntConfig(ENABLE);                          /* Enable SYSTICK Interrupt                           */
  SYSTICK_CounterCmd(SYSTICK_COUNTER_CLEAR);
  SYSTICK_CounterCmd(SYSTICK_COUNTER_ENABLE);
}

/*********************************************************************************************************//**
  * @brief  Configure the system clocks.
  * @retval None
  ***********************************************************************************************************/
void CKCU_Configuration(void)
{
  CKCU_PeripClockConfig_TypeDef CKCUClock = {{ 0 }};
  CKCUClock.Bit.AFIO                          = 1;
  CKCUClock.Bit.HTCFG_CAN_IPN                 = 1;
  #if defined(HTCFG_CAN_STB_CONTROL)
  CKCUClock.Bit.HTCFG_CAN_STB_GPIO_CK         = 1;
  #endif
  CKCU_PeripClockConfig(CKCUClock, ENABLE);
}

/*********************************************************************************************************//**
  * @brief  Configure the GPIO ports.
  * @retval None
  ***********************************************************************************************************/
void GPIO_Configuration(void)
{
  AFIO_GPxConfig(HTCFG_CAN_TX_GPIO_ID, HTCFG_CAN_TX_AFIO_PIN, AFIO_FUN_CAN);
  AFIO_GPxConfig(HTCFG_CAN_RX_GPIO_ID, HTCFG_CAN_RX_AFIO_PIN, AFIO_FUN_CAN);

  #if defined(HTCFG_CAN_STB_CONTROL)
  AFIO_GPxConfig(HTCFG_CAN_STB_GPIO_ID, HTCFG_CAN_STB_AFIO_PIN, AFIO_FUN_GPIO);
  GPIO_WriteOutBits(HTCFG_CAN_STB_GPIO_PORT, HTCFG_CAN_STB_AFIO_PIN, RESET);
  GPIO_DirectionConfig(HTCFG_CAN_STB_GPIO_PORT, HTCFG_CAN_STB_AFIO_PIN, GPIO_DIR_OUT);
  #endif
}

#if (HT32_LIB_DEBUG == 1)
/*********************************************************************************************************//**
  * @brief  Report both the error name of the source file and the source line number.
  * @param  filename: pointer to the source file name.
  * @param  uline: error line source number.
  * @retval None
  ***********************************************************************************************************/
void assert_error(u8* filename, u32 uline)
{
  /*
     This function is called by IP library that the invalid parameters has been passed to the library API.
     Debug message can be added here.
     Example: printf("Parameter Error: file %s on line %d\r\n", filename, uline);
  */

  while (1)
  {
  }
}
#endif


/**
  * @}
  */

/**
  * @}
  */

/**
  * @}
  */
