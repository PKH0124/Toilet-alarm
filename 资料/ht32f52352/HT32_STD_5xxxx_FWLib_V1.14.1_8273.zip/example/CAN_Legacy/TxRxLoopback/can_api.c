/*********************************************************************************************************//**
 * @file    CAN_Legacy/TxRxLoopback/can_api.c
 * @version $Rev:: 8216         $
 * @date    $Date:: 2024-10-23 #$
 * @brief   This file provides multiple can's APIs.
 *************************************************************************************************************
 * @attention
 *
 * Firmware Disclaimer Information
 *
 * 1. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, which is supplied by Holtek Semiconductor Inc., (hereinafter referred to as "HOLTEK") is the
 *    proprietary and confidential intellectual property of HOLTEK, and is protected by copyright law and
 *    other intellectual property laws.
 *
 * 2. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, is confidential information belonging to HOLTEK, and must not be disclosed to any third parties
 *    other than HOLTEK and the customer.
 *
 * 3. The program technical documentation, including the code, is provided "as is" and for customer reference
 *    only. After delivery by HOLTEK, the customer shall use the program technical documentation, including
 *    the code, at their own risk. HOLTEK disclaims any expressed, implied or statutory warranties, including
 *    the warranties of merchantability, satisfactory quality and fitness for a particular purpose.
 *
 * <h2><center>Copyright (C) Holtek Semiconductor Inc. All rights reserved</center></h2>
 ************************************************************************************************************/

/* Includes ------------------------------------------------------------------------------------------------*/
#include "ht32.h"
#include "ht32_board.h"
#include "can_api.h"
#include "string.h"

/* Global variables ----------------------------------------------------------------------------------------*/
STR_CANMSG_T_TypeDef rmsgfifo[16];
STR_CANMSG_T_TypeDef tmsgfifo[16];
can_queueTypeDef recvQ;
can_queueTypeDef sendQ;

/* Global functions ----------------------------------------------------------------------------------------*/
/**********************************************************************************************************//**
  * @brief  Send the test data 0xD9 0x04.
  * @retval None
  ***********************************************************************************************************/
void SendFirstTestDataD904(void)
{
  /* Send a standard frame transmission after power-on, data 0xD0 0x04. */
  CAN_MSG_TypeDef tMsg={0x00};
  u8 can_data[2] = {0xd9, 0x04};
  u32 i;
  /* Prepare data. */
  tMsg.MsgNum = 18; 
  tMsg.FrameType = CAN_DATA_FRAME;
  tMsg.IdType   = CAN_EXT_ID;
  tMsg.Id       = CAN_SEND_ID;
  CAN_Transmit(HT_CAN0, &tMsg, can_data, sizeof(can_data));
  
  printf("\r\nTx(<==), ID %06d, DLC %02d, EXT %d, Data: ", tMsg.Id, sizeof(can_data), tMsg.IdType);
  for(i = 0; i<sizeof(can_data); i++)
  {
    printf("%02X ", can_data[i]);
  }

  /* Send message. */
  HT32F_DVB_LEDOn(HT_LED1);
  while(!(HT_CAN0->SR & CAN_FLAG_TXOK));

  printf("Finish\r\n");

  /* clear TXOK flag. */
  HT_CAN0->SR &= ~CAN_FLAG_TXOK;
  /* Send message OK. */
  HT32F_DVB_LEDOff(HT_LED1);
}

/**********************************************************************************************************//**
  * @brief  Get CAN status.
  * @param  CANx: The pointer to CAN module base address.
  * @retval status : CAN_RET_TXOK         = 64
  *                  CAN_RET_RXOK         = 1
  *                  CAN_RET_IDLE         = 0
  *                  CAN_RET_BUSOFF_RCY   = -1
  *                  CAN_RET_EWARN        = -2
  *                  CAN_RET_RX_EMPTY     = -3
  ***********************************************************************************************************/
s8 GetCanStatus(HT_CAN_TypeDef *CANx)
{
  u32 intID;

  /* read interrupt pointer and status register */
  intID = CANx->IR;

  /** error interrupt.(triggered by BOFF or EWARN bit) **/
  if(intID == 0x8000)
  {
    /* CANbus at Bus-Off state. */
    if(CANx->SR & CAN_FLAG_BOFF)
    {
      return CAN_RET_BUSOFF_RCY;
    }

    /* CANbus at error warning status state. */
    if(CANx->SR & CAN_FLAG_EWARN)
    {
      return CAN_RET_EWARN;
    }
  }
  else
  {
    /** Transmitted or Received Message Successfully. **/
    if(intID >= 0x01 && intID <= 0x20)
    {
      /* Transmitted a Message Successfully. */
      if(CANx->SR & CAN_FLAG_TXOK)
      {
        /* clear TxOK status. */
        CANx->SR &= ~CAN_FLAG_TXOK;

        /* clear interrupt pending. */
        CANx->IF0.CMASK = (CAN_IF_CMASK_CLRINTPND | CAN_IF_CMASK_TXRQSTNEWDAT);
        CANx->IF0.CREQ = intID;
        return CAN_RET_TXOK;
      }
      else
      {
        /* Received a Message Successfully. */
        if(CANx->SR & CAN_FLAG_RXOK)
        {
          /* clear RxOK status. */
          CANx->SR &= ~CAN_FLAG_RXOK;
          return CAN_RET_RXOK;
        }
      }
    }
  }
  return CAN_RET_IDLE;
}

/*********************************************************************************************************//**
 * @brief  Get current bit rate
 * @param  CANx: The pointer to CAN module base address.
 * @retval Current Bit-Rate (kilo bit per second)
  ***********************************************************************************************************/
u32 CAN_GetCANBitRate(HT_CAN_TypeDef  *CANx)
{
  u32 wTseg1, wTseg2;
  u32 wBpr;

  wTseg1 = (CANx->BTR & CAN_BTR_TSEG0_Msk) >> CAN_BTR_TSEG0_Pos;
  wTseg2 = (CANx->BTR & CAN_BTR_TSEG1_Msk) >> CAN_BTR_TSEG1_Pos;
  wBpr  = CANx->BTR & CAN_BTR_BRP_Msk;
  wBpr |= CANx->BRPER << 6;

  return (SystemCoreClock / (wBpr + 1) / (wTseg1 + wTseg2 + 3));
}

/*********************************************************************************************************//**
 * @brief  Set bus baud-rate.
 * @param  CANx: The pointer to CAN module base address.
 * @param  wBaudRate: The target CAN baud-rate. The range of u32BaudRate is 1~1000KHz.
 * @retval CurrentBitRate: Real baud-rate value.
  ***********************************************************************************************************/
u32 CAN_SetBaudRate(HT_CAN_TypeDef *CANx, u32 wBaudRate)
{
  u32 wTseg0, wTseg1;
  u32 wBrp;
  u32 wValue;

  CANx->CR |= CAN_CR_INIT;
  CANx->CR |= CAN_CR_CCE;

  SystemCoreClockUpdate();

  wTseg0 = 2;
  wTseg1 = 1;

  wValue = SystemCoreClock / wBaudRate;

  while(1)
  {
    if(((wValue % (wTseg0 + wTseg1 + 3)) == 0))
      break;
    if(wTseg1 < 7)
      wTseg1++;

    if((wValue % (wTseg0 + wTseg1 + 3)) == 0)
      break;
    if(wTseg0 < 15)
      wTseg0++;
    else
    {
      wTseg0 = 2;
      wTseg1 = 1;
      break;
    }
  }

  wBrp  = SystemCoreClock / (wBaudRate) / (wTseg0 + wTseg1 + 3) - 1;

  wValue = ((u32)wTseg1 << CAN_BTR_TSEG1_Pos) | ((u32)wTseg0 << CAN_BTR_TSEG0_Pos) |
            (wBrp & CAN_BTR_BRP_Msk) | (CANx->BTR & CAN_BTR_SJW_Msk);
  CANx->BTR = wValue;
  CANx->BRPER = (wBrp >> 6) & 0x0F;

  CANx->CR &= (~(CAN_CR_INIT | CAN_CR_CCE));

  while(CANx->CR & CAN_CR_INIT); /* Check INIT bit is released */
 
  return (CAN_GetCANBitRate(CANx));
}

/*********************************************************************************************************//**
 * @brief  Set CAN operation mode and target baud-rate.
 * @param  CANx: The pointer to CAN module base address.
 * @param  wBaudRate The target CAN baud-rate. The range of u32BaudRate is 1~1000KHz.
 * @param  wMode The CAN operation mode.
 *         @arg  CAN_NORMAL_MODE : Normal operation.
 *         @arg  CAN_BASIC_MODE  : Basic operation.
 *         @arg  CAN_SILENT_MODE : Silent operation.
 *         @arg  CAN_LBACK_MODE  : Loop Back operation.
 *         @arg  CAN_LBS_MODE    : Loop Back combined with Silent  operation.
 * @retval u32CurrentBitRate Real baud-rate value.
  ***********************************************************************************************************/
u32 CAN_Open(HT_CAN_TypeDef *CANx, u32 wBaudRate, u32 wMode)
{
  u32 CurrentBitRate;

  CurrentBitRate = CAN_SetBaudRate(CANx, wBaudRate);

  if(wMode)
    CAN_EnterTestMode(CANx, wMode);

  return CurrentBitRate;
}

/*********************************************************************************************************//**
  * @brief  Configure the CAN.
  * @retval None
  ***********************************************************************************************************/
void CAN_Configuration(void)
{
  CAN_MSG_TypeDef rMsg={0x00};
  u32 RealBaudRate = 0;
  RealBaudRate = CAN_Open(HT_CAN0, CAN_BAUDRATE, CAN_MODE_NORMAL);

  if(CAN_BAUDRATE != RealBaudRate)
  {
      printf("\nSet CAN baud-rate is fail\n");
      printf("Real baud-rate value(bps): %d\n", RealBaudRate);
      printf("CAN baud-rate calculation equation as below:\n");
      printf("CAN baud-rate(bps) = Fin/(BPR+1)*(Tseg1+Tseg2+3)\n");
      printf("where: Fin: System clock freq.(Hz)\n");
      printf("       BRP: The baud rate prescale. It is composed of BRP (CAN_BTIME[5:0]) and BRPE (CAN_BRPE[3:0]).\n");
      printf("       Tseg1: Time Segment before the sample point. You can set tseg1 (CAN_BTIME[11:8]).\n");
      printf("       Tseg2: Time Segment after the sample point. You can set tseg2 (CAN_BTIME[14:12]).\n");

      if((SystemCoreClock) % CAN_BAUDRATE != 0)
          printf("\nThe BPR does not calculate, the Fin must be a multiple of the CAN baud-rate.\n");

      else
          printf("\nThe BPR does not calculate, the (Fin/(CAN baud-rate)) must be a multiple of the (Tseg1+Tseg1+3).\n");
  }
  else
  {
    printf("\nReal baud-rate value(bps): %d\n", RealBaudRate);
  }

  CAN_IntConfig(HT_CAN0, CAN_INT_EIE | CAN_INT_IE , ENABLE);

  rMsg.MsgNum   = 1;
  rMsg.FrameType = CAN_DATA_FRAME;
  rMsg.IdType   = CAN_STD_ID;
  rMsg.Id       = CAN_RECV_ID;
  rMsg.IdMask   = 0x7FFC;

  CAN_SetRxMsg(HT_CAN0, &rMsg , FIFO_DEPTH);

  recvQ.rptr = 0;
  recvQ.sptr = 0;
  recvQ.msg = rmsgfifo;

  sendQ.rptr = 0;
  sendQ.sptr = 0;
  sendQ.msg = tmsgfifo;
}

/*********************************************************************************************************//**
 * @brief  Read all the Message Object which have new data.
          (Only read the Message Object, don't check for new data, don't clear CAN_SR_RXOK_Msk)
 * @param  CANx: The pointer to CAN module base address.
 * @param  pQueueCanMsg: CAN msg FIFO.
 * @retval TRUE Success, FALSE No any message received
  ***********************************************************************************************************/
s32 ReadAllNewDataMsgObj(HT_CAN_TypeDef *CANx, can_queueTypeDef* pQueueCanMsg)
{
  u32 newDATA, i=0, j;
  CAN_MSG_TypeDef rrMsg={0x00};
  HT_CANIF_TypeDef *pIFx = 0;

  newDATA = HT_CAN0->NDR1;
  newDATA <<= 16;
  newDATA = newDATA + HT_CAN0->NDR0;

  if((CANx->IF0.CREQ & CAN_FLAG_IF_BUSY) == 0)
  {
    pIFx = &CANx->IF0;
  }
  else if((CANx->IF1.CREQ  & CAN_FLAG_IF_BUSY) == 0)
  {
    pIFx = &CANx->IF1;
  }
  else
  {
    return FALSE;
  }

  while(newDATA)
  {
    i++;
    /* read the message contents*/
      pIFx->CMASK = CAN_IF_CMASK_MASK
                      | CAN_IF_CMASK_ARB
                      | CAN_IF_CMASK_CONTROL
                      | CAN_IF_CMASK_CLRINTPND
                      | CAN_IF_CMASK_TXRQSTNEWDAT
                      | CAN_IF_CMASK_DATAA
                      | CAN_IF_CMASK_DATAB;

    pIFx->CREQ = i;

    if((pIFx->ARB1 & CAN_IF_ARB1_XTD) == 0)
    {
      /* standard ID*/
      rrMsg.IdType = CAN_STD_ID;
      rrMsg.Id     = (pIFx->ARB1 & CAN_IF_ARB1_ID_Msk) >> 2;
    }
    else
    {
      /* extended ID*/
      rrMsg.IdType = CAN_EXT_ID;
      rrMsg.Id = ((pIFx->ARB1) & 0x1FFF) << 16;
      rrMsg.Id |= pIFx->ARB0;
    }

    if((pIFx->ARB1 & CAN_IF_ARB1_DIR) == 0)
    {
      rrMsg.FrameType = CAN_DATA_FRAME;
    }
    else
    {
      rrMsg.FrameType = CAN_REMOTE_FRAME;
    }
    pQueueCanMsg->msg[pQueueCanMsg->rptr].Id = rrMsg.Id;
    pQueueCanMsg->msg[pQueueCanMsg->rptr].FrameType = rrMsg.FrameType;
    pQueueCanMsg->msg[pQueueCanMsg->rptr].IdType = rrMsg.IdType;

    pQueueCanMsg->msg[pQueueCanMsg->rptr].DLC     = pIFx->MCR & CAN_IF_MCR_DLC_Msk;
    pQueueCanMsg->msg[pQueueCanMsg->rptr].Data[0] = pIFx->DA0R & CAN_IF_DAT_A0_DATA0_Msk;
    pQueueCanMsg->msg[pQueueCanMsg->rptr].Data[1] = (pIFx->DA0R & CAN_IF_DAT_A0_DATA1_Msk) >> CAN_IF_DAT_A0_DATA1_Pos;
    pQueueCanMsg->msg[pQueueCanMsg->rptr].Data[2] = pIFx->DA1R & CAN_IF_DAT_A1_DATA2_Msk;
    pQueueCanMsg->msg[pQueueCanMsg->rptr].Data[3] = (pIFx->DA1R & CAN_IF_DAT_A1_DATA3_Msk) >> CAN_IF_DAT_A1_DATA3_Pos;
    pQueueCanMsg->msg[pQueueCanMsg->rptr].Data[4] = pIFx->DB0R & CAN_IF_DAT_B0_DATA4_Msk;
    pQueueCanMsg->msg[pQueueCanMsg->rptr].Data[5] = (pIFx->DB0R & CAN_IF_DAT_B0_DATA5_Msk) >> CAN_IF_DAT_B0_DATA5_Pos;
    pQueueCanMsg->msg[pQueueCanMsg->rptr].Data[6] = pIFx->DB1R & CAN_IF_DAT_B1_DATA6_Msk;
    pQueueCanMsg->msg[pQueueCanMsg->rptr].Data[7] = (pIFx->DB1R & CAN_IF_DAT_B1_DATA7_Msk) >> CAN_IF_DAT_B1_DATA7_Pos;
    printf("\r\nRx(==>), ID %06d, DLC %02d, EXT %d, Data: ", rrMsg.Id, 
                                                             pQueueCanMsg->msg[pQueueCanMsg->rptr].DLC, 
                                                             rrMsg.IdType);
    for(j = 0; j<pQueueCanMsg->msg[pQueueCanMsg->rptr].DLC; j++)
    {
      printf("%02X ", pQueueCanMsg->msg[pQueueCanMsg->rptr].Data[j]);
    }
    printf("Finish\r\n");

    pQueueCanMsg->rptr++;
    if(pQueueCanMsg->rptr == FIFO_DEPTH)
    {
      pQueueCanMsg->rptr = 0;
    }
    newDATA = newDATA>>1;
  }
  return TRUE;
}

/**********************************************************************************************************//**
  * @brief  check ring buffer delta
  * @param  a
  * @param  b
  * @param  dup
  * @retval delta : number of delta.
  ***********************************************************************************************************/
u8 RmemDelta(u8 a, u8 b, u8 dup)
{
  u8 delta;

  delta = a - b;

  if(delta & 0x80)
  {
    delta = delta + dup;
  }
  return delta;
}
