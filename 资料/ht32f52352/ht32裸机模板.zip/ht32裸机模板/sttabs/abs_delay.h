#ifndef __ABS_DELAY_H__
#define __ABS_DELAY_H__
 
#include "ht32.h"

void Abs_Delay_Us(uint32_t us);
void Abs_Delay_Ms(uint32_t ms);

#endif


